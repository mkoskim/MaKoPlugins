-- ****************************************************************************
-- ****************************************************************************
--
-- Window, that handles ESC and F12.
--
-- ****************************************************************************
-- ****************************************************************************

-- ----------------------------------------------------------------------------

Window = class(Turbine.UI.Lotro.Window)

function Window:Constructor()
    Turbine.UI.Lotro.Window.Constructor(self)

    self.storedstate = {
        Visible = false
    }

    self:SetWantsKeyEvents(true)
end

-- ----------------------------------------------------------------------------

function Window:VisibleChanged(args)
    self.storedstate.Visible = self:IsVisible()
end

-- ----------------------------------------------------------------------------

function Window:KeyDown(args)
    if args.Action == Actions.ESC then
        if self:IsVisible() then
            self:SetVisible(false)
        end
    elseif args.Action == Actions.HUDToggle then
        if self.storedVisibility == nil then
            self.storedVisibility = self:IsVisible()
            self:SetVisible(false)
        else
            self:SetVisible(self.storedVisibility)
            self.storedVisibility = nil
        end
    end
end

-- ----------------------------------------------------------------------------

function Window:Serialize()
    return {
        Left = self:GetLeft(),
        Top = self:GetTop(),
        Width = self:GetWidth(),
        Height = self:GetHeight(),
        Visible = self.storedstate.Visible,
    }
end

function Window:Deserialize(settings)
    self:SetPosition(settings.Left, settings.Top)
    self:SetSize(settings.Width, settings.Height)
    self:SetVisible(settings.Visible)
end

