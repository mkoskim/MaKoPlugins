-- ****************************************************************************
-- ****************************************************************************
--
-- DesktopButton is draggable 'freefloating' button on game window, mainly
-- for showing / hiding plugin main window.
--
-- ****************************************************************************
-- ****************************************************************************

DesktopButton = class(Turbine.UI.Window)

function DesktopButton:Constructor( text )
    Turbine.UI.Window.Constructor(self)

    self:SetSize(32, 32)
    self:SetBackColor(Turbine.UI.Color.Black)

    self.button = TextButton()
    self.button:SetParent(self)
    self.button:SetText(text)

    self.button:SetPosition(1, 1)
    self.button:SetSize(30, 30)
end

-- ----------------------------------------------------------------------------

ToggleWindowButton = class(DesktopButton)

function ToggleWindowButton:Constructor(text, window)
    DesktopButton.Constructor(self, text)

    self.window = window
end

